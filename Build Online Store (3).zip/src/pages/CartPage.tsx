import { useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { useStore } from '../context/StoreContext'

function WhatsAppIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}

function formatPrice(price: number) {
  return new Intl.NumberFormat('ar-MA', { maximumFractionDigits: 0 }).format(price)
}

export default function CartPage() {
  const { cart, products, settings, updateCartQuantity, removeFromCart } = useStore()
  const cartItems = Object.entries(cart)
    .map(([id, quantity]) => ({ product: products.find((product) => product.id === id), quantity }))
    .filter((item): item is { product: (typeof products)[number]; quantity: number } => Boolean(item.product))
  const subtotal = cartItems.reduce((sum, { product, quantity }) => sum + product.price * quantity, 0)
  const shipping = subtotal >= 500 ? 0 : 30
  const total = subtotal + shipping
  const [customer, setCustomer] = useState({ name: '', phone: '', city: '', address: '', notes: '' })
  const setField = (field: keyof typeof customer) => (e: { target: { value: string } }) =>
    setCustomer((prev) => ({ ...prev, [field]: e.target.value }))

  const sendOrderToWhatsApp = (e: FormEvent) => {
    e.preventDefault()
    const line = '------------------------------------'
    let message = `📦 *طلب جديد من متجر alipack* 📦\n\n`
    message += `مرحباً! أود تأكيد طلبي عبر الموقع:\n${line}\n\n`
    message += `🛒 *تفاصيل المنتجات:*\n`
    cartItems.forEach(({ product, quantity }, index) => {
      message += `${index + 1}. *${product.name}*\n`
      message += `   🔹 الكمية: ${quantity} | السعر: ${product.price} د.م\n`
    })
    message += `\n${line}\n`
    message += `🚚 *التوصيل:* ${shipping ? `${shipping} درهم` : 'مجاني'}\n`
    message += `💰 *المجموع الإجمالي:* *${total} درهم*\n${line}\n\n`
    message += `👤 *معلومات المشتري:*\n`
    message += `• *الاسم:* ${customer.name.trim()}\n`
    message += `• *الهاتف:* ${customer.phone.trim()}\n`
    message += `• *المدينة:* ${customer.city.trim()}\n`
    message += `• *العنوان:* ${customer.address.trim()}\n`
    if (customer.notes.trim()) message += `• *ملاحظة:* ${customer.notes.trim()}\n`
    message += `\n✨ *شكراً لثقتكم بـ alipack! ننتظر تأكيدكم للبدء في تجهيز الشحنة.*`
    window.open(`https://wa.me/212766865756?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer')
  }

  const field = 'peer w-full rounded-xl border border-slate-200 bg-white px-4 pb-2 pt-6 text-[15px] text-[#0b2545] outline-none transition placeholder-transparent focus:border-[#0b2545] focus:ring-4 focus:ring-[#0b2545]/10'
  const label = 'pointer-events-none absolute right-4 top-4 origin-top-right text-sm text-slate-500 transition-all peer-focus:top-2 peer-focus:text-[11px] peer-focus:text-[#0b2545] peer-[:not(:placeholder-shown)]:top-2 peer-[:not(:placeholder-shown)]:text-[11px]'
  const card = 'rounded-2xl bg-white shadow-[0_2px_4px_rgba(11,37,69,0.04),0_12px_32px_rgba(11,37,69,0.07)]'

  const trust = [
    { title: 'شحن سريع لكل المغرب', sub: 'توصيل خلال 24 – 72 ساعة', d: 'M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10m10 0H3m10 0h2m4 0h1v-5l-3-4h-4v9m-6 0a2 2 0 104 0m8 0a2 2 0 11-4 0' },
    { title: 'ضمان الجودة', sub: 'كرتون مقوّى مطابق للمواصفات', d: 'M9 12l2 2 4-4m5.6-3.1A12 12 0 0112 2.9 12 12 0 013.4 6.9 12 12 0 0012 21a12 12 0 008.6-14.1z' },
    { title: 'الدفع عند الاستلام', sub: 'لا تدفع إلا بعد المعاينة', d: 'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z' },
  ]

  return (
    <div dir="rtl" className="min-h-screen bg-[#f1f4f8] font-['Cairo',sans-serif] text-[#0b2545]">
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
          <Link to="/" className="flex items-center gap-2 text-sm font-semibold text-slate-600 transition hover:text-[#0b2545]">
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
            <span className="hidden sm:inline">العودة إلى المتجر</span>
            <span className="sm:hidden">المتجر</span>
          </Link>
          <Link to="/" className="flex items-center gap-2" aria-label="alipack">
            <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-[#0b2545] text-white">
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M21 8l-9-5-9 5m18 0l-9 5m9-5v8l-9 5m0-8L3 8m9 5v8M3 8v8l9 5" /></svg>
            </span>
            <span className="text-xl font-extrabold tracking-tight" dir="ltr">ali<span className="text-[#12b866]">pack</span></span>
          </Link>
          <span className="flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700">
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0-1.1.9-2 2-2m-2 2a2 2 0 10-4 0v1h6v-1a2 2 0 00-2-2zM6 12h12v8H6z" /></svg>
            <span className="hidden sm:inline">دفع آمن ومضمون</span>
            <span className="sm:hidden">آمن</span>
          </span>
        </div>
      </header>

      {!cartItems.length ? (
        <main className="mx-auto flex min-h-[70vh] max-w-md items-center px-4">
          <div className={`${card} w-full p-10 text-center`}>
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#0b2545]/5 text-[#0b2545]">
              <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.6} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 2.3c-.6.6-.2 1.7.7 1.7H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
            </div>
            <h1 className="mt-5 text-2xl font-extrabold">سلتك فارغة حالياً</h1>
            <p className="mt-2 text-sm leading-7 text-slate-500">أضف منتجات التعبئة التي تحتاجها وأكمل طلبك بسهولة عبر واتساب.</p>
            <Link to="/" className="mt-6 inline-flex rounded-xl bg-[#0b2545] px-6 py-3 text-sm font-bold text-white transition hover:bg-[#143560]">اكتشف المنتجات</Link>
          </div>
        </main>
      ) : (
        <main className="mx-auto max-w-6xl px-4 pb-16 pt-6 sm:pt-10">
          <div className="mb-6 flex items-end justify-between">
            <div>
              <h1 className="text-2xl font-extrabold sm:text-3xl">إتمام الطلب</h1>
              <p className="mt-1 text-sm text-slate-500">{cartItems.length} {cartItems.length > 2 ? 'منتجات' : 'منتج'} في سلتك · الدفع عند الاستلام</p>
            </div>
          </div>

          <form onSubmit={sendOrderToWhatsApp} className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_24rem]">
            <div className="space-y-6">
              <section className={`${card} p-4 sm:p-6`} aria-labelledby="items-title">
                <h2 id="items-title" className="mb-4 flex items-center gap-3 text-lg font-extrabold">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#0b2545] text-xs text-white">1</span>
                  ملخص المنتجات
                </h2>
                <ul className="space-y-3">
                  {cartItems.map(({ product, quantity }) => (
                    <li key={product.id} className="grid grid-cols-[4.5rem_minmax(0,1fr)] gap-3 rounded-2xl border border-slate-100 bg-[#f8fafc] p-3 sm:grid-cols-[5.5rem_minmax(0,1fr)_auto] sm:items-center sm:gap-4">
                      <img src={product.images[0]} alt={product.name} className="h-[4.5rem] w-[4.5rem] rounded-xl bg-slate-100 object-cover sm:h-[5.5rem] sm:w-[5.5rem]" />
                      <div className="min-w-0">
                        <Link to={`/product/${product.slug}`} className="line-clamp-2 text-[15px] font-bold leading-6 transition hover:text-emerald-700">{product.name}</Link>
                        <p className="mt-0.5 text-sm text-slate-500">{formatPrice(product.price)} <span className="text-xs">MAD / قطعة</span></p>
                        <button type="button" onClick={() => removeFromCart(product.id)} className="mt-1 text-xs font-semibold text-rose-600 hover:underline">حذف</button>
                      </div>
                      <div className="col-span-2 flex items-center justify-between gap-3 border-t border-slate-200/70 pt-3 sm:col-span-1 sm:flex-col sm:items-end sm:border-0 sm:pt-0">
                        <div className="flex items-center rounded-xl border border-slate-200 bg-white">
                          <button type="button" aria-label="تقليل الكمية" onClick={() => updateCartQuantity(product.id, quantity - 1)} className="flex h-9 w-9 items-center justify-center rounded-r-xl text-lg transition hover:bg-slate-100">−</button>
                          <span className="w-8 text-center text-sm font-extrabold tabular-nums">{quantity}</span>
                          <button type="button" aria-label="زيادة الكمية" onClick={() => updateCartQuantity(product.id, quantity + 1)} className="flex h-9 w-9 items-center justify-center rounded-l-xl text-lg transition hover:bg-slate-100">+</button>
                        </div>
                        <p className="text-base font-extrabold tabular-nums">{formatPrice(product.price * quantity)} <span className="text-xs font-bold text-slate-500">MAD</span></p>
                      </div>
                    </li>
                  ))}
                </ul>
              </section>

              <section className={`${card} p-4 sm:p-6`} aria-labelledby="details-title">
                <h2 id="details-title" className="mb-4 flex items-center gap-3 text-lg font-extrabold">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#0b2545] text-xs text-white">2</span>
                  معلومات التوصيل
                </h2>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="relative">
                    <input id="f-name" required value={customer.name} onChange={setField('name')} placeholder="الاسم الكامل" autoComplete="name" className={field} />
                    <label htmlFor="f-name" className={label}>الاسم الكامل</label>
                  </div>
                  <div className="relative">
                    <input id="f-phone" required type="tel" inputMode="tel" dir="rtl" value={customer.phone} onChange={setField('phone')} placeholder="رقم الهاتف" autoComplete="tel" className={field} />
                    <label htmlFor="f-phone" className={label}>رقم الهاتف (07 00 00 00 00)</label>
                  </div>
                  <div className="relative sm:col-span-2">
                    <input id="f-city" required value={customer.city} onChange={setField('city')} placeholder="المدينة" autoComplete="address-level2" className={field} />
                    <label htmlFor="f-city" className={label}>المدينة</label>
                  </div>
                  <div className="relative sm:col-span-2">
                    <input id="f-address" required value={customer.address} onChange={setField('address')} placeholder="عنوان التوصيل" autoComplete="street-address" className={field} />
                    <label htmlFor="f-address" className={label}>عنوان التوصيل</label>
                  </div>
                  <div className="relative sm:col-span-2">
                    <textarea id="f-notes" rows={3} value={customer.notes} onChange={setField('notes')} placeholder="ملاحظات الطلب" className={`${field} resize-none`} />
                    <label htmlFor="f-notes" className={label}>ملاحظات الطلب (اختياري)</label>
                  </div>
                </div>
              </section>
            </div>

            <aside className="space-y-4 lg:sticky lg:top-24">
              <div className={`${card} p-5 sm:p-6`}>
                <h2 className="text-lg font-extrabold">ملخص الطلب</h2>
                <dl className="mt-4 space-y-3 text-sm">
                  <div className="flex justify-between"><dt className="text-slate-500">المجموع الفرعي</dt><dd className="font-bold tabular-nums">{formatPrice(subtotal)} MAD</dd></div>
                  <div className="flex justify-between"><dt className="text-slate-500">رسوم التوصيل</dt><dd className={`font-bold tabular-nums ${shipping ? '' : 'text-emerald-600'}`}>{shipping ? `${formatPrice(shipping)} MAD` : 'مجاني'}</dd></div>
                </dl>
                {shipping > 0 && (
                  <p className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-xs font-semibold leading-6 text-amber-800">أضف {formatPrice(500 - subtotal)} MAD للحصول على توصيل مجاني.</p>
                )}
                <div className="mt-4 flex items-center justify-between rounded-xl bg-[#0b2545] px-4 py-4 text-white">
                  <span className="text-sm font-bold">المبلغ الإجمالي</span>
                  <span className="text-2xl font-extrabold tabular-nums">{formatPrice(total)} <small className="text-sm font-bold text-white/70">MAD</small></span>
                </div>
                <button type="submit" className="mt-4 flex w-full items-center justify-center gap-3 rounded-xl bg-[#25D366] px-4 py-4 text-base font-extrabold text-white shadow-[0_10px_24px_rgba(37,211,102,0.35)] transition hover:-translate-y-0.5 hover:bg-[#1fbd5b] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0b2545]">
                  <WhatsAppIcon className="h-6 w-6" />
                  تأكيد الطلب عبر الواتساب
                </button>
                <p className="mt-3 text-center text-xs text-slate-500">سنتواصل معك عبر واتساب لتأكيد الطلب قبل الشحن.</p>
              </div>

              <ul className={`${card} divide-y divide-slate-100`}>
                {trust.map((t) => (
                  <li key={t.title} className="flex items-center gap-3 px-4 py-3.5">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
                      <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d={t.d} /></svg>
                    </span>
                    <span><span className="block text-sm font-bold">{t.title}</span><span className="block text-xs text-slate-500">{t.sub}</span></span>
                  </li>
                ))}
              </ul>
            </aside>
          </form>
        </main>
      )}
    </div>
  )
}
