export interface Category {
  id: string
  name: string
  slug: string
  description: string
  image_url: string | null
  created_at: string
}

export interface Product {
  id: string
  name: string
  slug: string
  description: string
  price: number
  compare_at_price: number | null
  category_id: string
  images: string[]
  is_featured: boolean
  in_stock: boolean
  specifications: Record<string, string>
  created_at: string
}

export interface StoreSettings {
  store_name: string
  store_description: string
  logo_url: string | null
  whatsapp_number: string
  phone: string
  email: string
  address: string
  hero_title: string
  hero_subtitle: string
  hero_image_url: string | null
  hero_video_url: string | null
  featured_product_id: string | null
  instagram_url: string
  facebook_url: string
  tiktok_url: string
  youtube_url: string
  delivery_text: string
  cod_text: string
  return_text: string
  support_text: string
  support_hours: string
  primary_color: string
  secondary_color: string
  accent_color: string
  meta_title: string
  meta_description: string
}

export interface OrderFormData {
  name: string
  phone: string
  city: string
  address: string
  quantity: number
  variant: string
  note: string
}
