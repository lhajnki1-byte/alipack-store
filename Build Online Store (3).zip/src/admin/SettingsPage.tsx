import { useState } from 'react'
import { useStore } from '../context/StoreContext'
import type { StoreSettings } from '../types'

type Tab = 'store' | 'contact' | 'homepage' | 'social' | 'business' | 'seo'

const TABS: { id: Tab; label: string }[] = [
  { id: 'store', label: 'المتجر' },
  { id: 'contact', label: 'التواصل' },
  { id: 'homepage', label: 'الرئيسية' },
  { id: 'social', label: 'التواصل الاجتماعي' },
  { id: 'business', label: 'معلومات العمل' },
  { id: 'seo', label: 'SEO' },
]

export default function SettingsPage() {
  const { settings, setSettings, products } = useStore()
  const [form, setForm] = useState<StoreSettings>({ ...settings })
  const [activeTab, setActiveTab] = useState<Tab>('store')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  function update(key: keyof StoreSettings, value: string | null) {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  async function handleSave() {
    setSaving(true)
    await new Promise((r) => setTimeout(r, 400))
    setSettings(form)
    setSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  const field = (label: string, key: keyof StoreSettings, type = 'text', placeholder = '') => (
    <div>
      <label className="block text-sm font-medium text-[#111] mb-1.5">{label}</label>
      <input
        type={type}
        value={(form[key] as string) ?? ''}
        onChange={(e) => update(key, e.target.value || null)}
        placeholder={placeholder}
        className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] transition-colors"
      />
    </div>
  )

  const textarea = (label: string, key: keyof StoreSettings, placeholder = '') => (
    <div>
      <label className="block text-sm font-medium text-[#111] mb-1.5">{label}</label>
      <textarea
        value={(form[key] as string) ?? ''}
        onChange={(e) => update(key, e.target.value || null)}
        placeholder={placeholder}
        rows={3}
        className="w-full px-4 py-3 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] transition-colors resize-none"
      />
    </div>
  )

  return (
    <div className="p-6 max-w-2xl">
      {saved && (
        <div className="fixed top-4 start-4 z-50 bg-[#0f5c35] text-white text-sm font-medium px-4 py-3 rounded-xl shadow-lg">
          ✓ تم حفظ الإعدادات
        </div>
      )}

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[#111]">إعدادات المتجر</h1>
        <p className="text-sm text-[#6b6b6b] mt-1">إدارة جميع إعدادات متجرك</p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1 mb-6 bg-[#f5f0eb] p-1 rounded-xl">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === tab.id ? 'bg-white text-[#111] shadow-sm' : 'text-[#6b6b6b] hover:text-[#111]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-[#e8e4de] p-5 space-y-4">
        {activeTab === 'store' && (
          <>
            {field('اسم المتجر', 'store_name', 'text', 'علي باك')}
            {textarea('وصف المتجر', 'store_description', 'وصف قصير عن متجرك...')}
            {field('رابط الشعار (Logo)', 'logo_url', 'url', 'https://...')}
          </>
        )}

        {activeTab === 'contact' && (
          <>
            {field('رقم واتساب', 'whatsapp_number', 'tel', '+212600000000')}
            {field('رقم الهاتف', 'phone', 'tel', '+212522000000')}
            {field('البريد الإلكتروني', 'email', 'email', 'contact@alipack.ma')}
            {field('العنوان', 'address', 'text', 'الدار البيضاء، المغرب')}
          </>
        )}

        {activeTab === 'homepage' && (
          <>
            {field('عنوان الهيرو', 'hero_title', 'text', 'جودة التغليف، أسعار لا تُنافَس')}
            {textarea('نص الهيرو', 'hero_subtitle', 'وصف تحت العنوان...')}
            {field('رابط صورة الهيرو', 'hero_image_url', 'url', 'https://...')}
            {field('رابط فيديو الهيرو (اختياري)', 'hero_video_url', 'url', 'https://...')}
            <div>
              <label className="block text-sm font-medium text-[#111] mb-1.5">المنتج المميز في الرئيسية</label>
              <select
                value={form.featured_product_id ?? ''}
                onChange={(e) => update('featured_product_id', e.target.value || null)}
                className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] bg-white"
              >
                <option value="">بدون منتج مميز</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>
          </>
        )}

        {activeTab === 'social' && (
          <>
            {field('Instagram', 'instagram_url', 'url', 'https://instagram.com/...')}
            {field('Facebook', 'facebook_url', 'url', 'https://facebook.com/...')}
            {field('TikTok', 'tiktok_url', 'url', 'https://tiktok.com/@...')}
            {field('YouTube', 'youtube_url', 'url', 'https://youtube.com/...')}
          </>
        )}

        {activeTab === 'business' && (
          <>
            {textarea('نص التوصيل', 'delivery_text', 'توصيل سريع لجميع مدن المغرب...')}
            {textarea('نص الدفع عند التسليم', 'cod_text', 'الدفع عند التسليم متاح...')}
            {textarea('نص الإرجاع والتبديل', 'return_text', 'إمكانية الإرجاع خلال...')}
            {textarea('نص دعم العملاء', 'support_text', 'فريق دعم متخصص...')}
            {field('ساعات العمل', 'support_hours', 'text', 'السبت–الخميس، 9 صباحاً – 6 مساءً')}
          </>
        )}

        {activeTab === 'seo' && (
          <>
            {field('Meta Title', 'meta_title', 'text', 'علي باك — مواد التغليف بالمغرب')}
            {textarea('Meta Description', 'meta_description', 'وصف قصير يظهر في نتائج البحث...')}
          </>
        )}
      </div>

      <button
        onClick={handleSave}
        disabled={saving}
        className="mt-5 w-full h-12 bg-[#0f5c35] text-white font-semibold rounded-xl hover:bg-[#0a4a2a] transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
      >
        {saving && (
          <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
        )}
        {saving ? 'جار الحفظ...' : 'حفظ الإعدادات'}
      </button>
    </div>
  )
}
