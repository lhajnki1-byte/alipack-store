import { Link } from 'react-router-dom'

export default function NotFoundPage() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center px-4 text-center">
      <p className="text-7xl font-black text-[#0f5c35] mb-4">٤٠٤</p>
      <h1 className="text-2xl font-bold text-[#111] mb-2">الصفحة غير موجودة</h1>
      <p className="text-[#6b6b6b] text-sm mb-8 max-w-xs">الصفحة التي تبحث عنها غير موجودة أو تم نقلها</p>
      <div className="flex gap-3">
        <Link
          to="/"
          className="px-5 py-2.5 bg-[#0f5c35] text-white font-semibold rounded-lg text-sm hover:bg-[#0a4a2a] transition-colors"
        >
          العودة للرئيسية
        </Link>
        <Link
          to="/search"
          className="px-5 py-2.5 border border-[#e8e4de] text-[#111] font-semibold rounded-lg text-sm hover:bg-[#f4f1ec] transition-colors"
        >
          البحث
        </Link>
      </div>
    </div>
  )
}
