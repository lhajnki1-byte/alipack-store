import { Link } from 'react-router-dom'
import { useStore } from '../context/StoreContext'

export default function DashboardPage() {
  const { products, categories, settings, getFeaturedProduct } = useStore()
  const featured = getFeaturedProduct()
  const inStockCount = products.filter((p) => p.in_stock).length
  const outOfStockCount = products.filter((p) => !p.in_stock).length
  const featuredCount = products.filter((p) => p.is_featured).length

  const stats = [
    {
      label: 'إجمالي المنتجات',
      value: products.length,
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10" />
        </svg>
      ),
      color: 'bg-[#0f5c35]',
      link: '/admin/products',
    },
    {
      label: 'التصنيفات',
      value: categories.length,
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
        </svg>
      ),
      color: 'bg-[#c49a2a]',
      link: '/admin/categories',
    },
    {
      label: 'متوفر',
      value: inStockCount,
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      color: 'bg-green-600',
      link: '/admin/products',
    },
    {
      label: 'نفد المخزون',
      value: outOfStockCount,
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      color: 'bg-red-500',
      link: '/admin/products',
    },
  ]

  return (
    <div className="p-6 max-w-5xl">
      {/* Header */}
      <div className="mb-7">
        <h1 className="text-2xl font-bold text-[#111]">لوحة التحكم</h1>
        <p className="text-sm text-[#6b6b6b] mt-1">مرحباً بك في {settings.store_name}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat) => (
          <Link
            key={stat.label}
            to={stat.link}
            className="bg-white rounded-xl p-5 border border-[#e8e4de] hover:shadow-md transition-shadow group"
          >
            <div className={`w-11 h-11 rounded-xl ${stat.color} flex items-center justify-center text-white mb-3`}>
              {stat.icon}
            </div>
            <p className="text-3xl font-bold text-[#111] mb-1">{stat.value}</p>
            <p className="text-sm text-[#6b6b6b]">{stat.label}</p>
          </Link>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Featured product */}
        <div className="bg-white rounded-xl border border-[#e8e4de] p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-[#111]">المنتج المميز الحالي</h2>
            <Link to="/admin/settings" className="text-xs text-[#0f5c35] hover:underline">تغيير</Link>
          </div>
          {featured ? (
            <div className="flex items-center gap-3">
              {featured.images[0] && (
                <img src={featured.images[0]} alt={featured.name} className="w-14 h-14 rounded-lg object-cover bg-[#f4f1ec] flex-shrink-0" />
              )}
              <div className="min-w-0">
                <p className="font-medium text-sm text-[#111] truncate">{featured.name}</p>
                <p className="text-[#0f5c35] font-bold text-sm">{featured.price.toLocaleString('ar-MA')} درهم</p>
                <span className="inline-flex items-center gap-1 text-xs bg-[#c49a2a]/15 text-[#9a7a1f] px-2 py-0.5 rounded-full mt-1">
                  ⭐ مميز
                </span>
              </div>
            </div>
          ) : (
            <p className="text-sm text-[#6b6b6b]">لم يتم تحديد منتج مميز بعد</p>
          )}
        </div>

        {/* Quick actions */}
        <div className="bg-white rounded-xl border border-[#e8e4de] p-5">
          <h2 className="font-semibold text-[#111] mb-4">إجراءات سريعة</h2>
          <div className="space-y-2">
            <Link
              to="/admin/products"
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-[#f4f1ec] transition-colors group"
            >
              <div className="w-8 h-8 rounded-lg bg-[#0f5c35]/10 flex items-center justify-center text-[#0f5c35]">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <span className="text-sm font-medium text-[#111]">إضافة منتج جديد</span>
            </Link>
            <Link
              to="/admin/categories"
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-[#f4f1ec] transition-colors group"
            >
              <div className="w-8 h-8 rounded-lg bg-[#c49a2a]/10 flex items-center justify-center text-[#c49a2a]">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <span className="text-sm font-medium text-[#111]">إضافة تصنيف جديد</span>
            </Link>
            <Link
              to="/admin/settings"
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-[#f4f1ec] transition-colors group"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
              </div>
              <span className="text-sm font-medium text-[#111]">تعديل إعدادات المتجر</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Recent products */}
      <div className="mt-6 bg-white rounded-xl border border-[#e8e4de]">
        <div className="flex items-center justify-between p-5 border-b border-[#e8e4de]">
          <h2 className="font-semibold text-[#111]">أحدث المنتجات</h2>
          <Link to="/admin/products" className="text-xs text-[#0f5c35] hover:underline">عرض الكل</Link>
        </div>
        <div className="divide-y divide-[#e8e4de]">
          {products.slice(0, 5).map((product) => {
            const cat = categories.find((c) => c.id === product.category_id)
            return (
              <div key={product.id} className="flex items-center gap-3 px-5 py-3.5">
                {product.images[0] ? (
                  <img src={product.images[0]} alt={product.name} className="w-10 h-10 rounded-lg object-cover bg-[#f4f1ec] flex-shrink-0" />
                ) : (
                  <div className="w-10 h-10 rounded-lg bg-[#f4f1ec] flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#111] truncate">{product.name}</p>
                  <p className="text-xs text-[#6b6b6b]">{cat?.name}</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <span className="text-sm font-semibold text-[#0f5c35]">{product.price} د.م</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${product.in_stock ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>
                    {product.in_stock ? 'متوفر' : 'نفد'}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
