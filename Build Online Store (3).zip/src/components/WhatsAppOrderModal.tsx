import { useState, useEffect } from 'react'
import type { Product } from '../types'
import { useStore } from '../context/StoreContext'

interface Props {
  product: Product | null
  onClose: () => void
}

export default function WhatsAppOrderModal({ product, onClose }: Props) {
  const { settings } = useStore()
  const [form, setForm] = useState({
    name: '',
    phone: '',
    city: '',
    address: '',
    quantity: 1,
    note: '',
  })
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (product) {
      document.body.style.overflow = 'hidden'
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [product])

  if (!product) return null

  function validate(): boolean {
    const e: Record<string, string> = {}
    if (!form.name.trim()) e.name = 'الاسم مطلوب'
    if (!form.phone.trim()) e.phone = 'رقم الهاتف مطلوب'
    if (!form.city.trim()) e.city = 'المدينة مطلوبة'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  function handleOrder() {
    if (!validate()) return

    const total = (product!.price * form.quantity).toLocaleString('ar-MA')
    const message = [
      `🛒 *طلب جديد — ${settings.store_name}*`,
      ``,
      `📦 *المنتج:* ${product!.name}`,
      `🔢 *الكمية:* ${form.quantity}`,
      `💰 *السعر الإجمالي:* ${total} درهم`,
      ``,
      `👤 *اسم العميل:* ${form.name}`,
      `📱 *الهاتف:* ${form.phone}`,
      `🏙️ *المدينة:* ${form.city}`,
      form.address ? `📍 *العنوان:* ${form.address}` : null,
      form.note ? `📝 *ملاحظة:* ${form.note}` : null,
    ]
      .filter(Boolean)
      .join('\n')

    const waNumber = settings.whatsapp_number.replace(/\D/g, '')
    const url = `https://wa.me/${waNumber}?text=${encodeURIComponent(message)}`
    window.open(url, '_blank')
    onClose()
  }

  function handleChange(field: string, value: string | number) {
    setForm((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: '' }))
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      {/* Sheet */}
      <div className="relative bg-white w-full sm:max-w-md sm:rounded-2xl rounded-t-2xl max-h-[92vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-[#e8e4de] px-5 py-4 flex items-center justify-between z-10">
          <div>
            <h2 className="font-bold text-lg text-[#111]">اطلب عبر واتساب</h2>
            <p className="text-xs text-[#6b6b6b] mt-0.5">{product.name}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-[#f4f1ec] transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Product summary */}
        <div className="px-5 py-4 bg-[#f5f0eb] border-b border-[#e8e4de] flex items-center gap-3">
          {product.images[0] && (
            <img src={product.images[0]} alt={product.name} className="w-14 h-14 rounded-lg object-cover bg-white flex-shrink-0" />
          )}
          <div className="min-w-0">
            <p className="font-semibold text-sm text-[#111] line-clamp-2">{product.name}</p>
            <p className="text-[#0f5c35] font-bold mt-0.5">{product.price.toLocaleString('ar-MA')} درهم</p>
          </div>
        </div>

        {/* Form */}
        <div className="px-5 py-5 space-y-4">
          {/* Quantity */}
          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">الكمية</label>
            <div className="flex items-center gap-3">
              <button
                onClick={() => handleChange('quantity', Math.max(1, form.quantity - 1))}
                className="w-10 h-10 rounded-lg border border-[#e8e4de] flex items-center justify-center text-xl hover:bg-[#f4f1ec] transition-colors font-light"
              >−</button>
              <span className="text-lg font-bold text-[#111] w-8 text-center">{form.quantity}</span>
              <button
                onClick={() => handleChange('quantity', form.quantity + 1)}
                className="w-10 h-10 rounded-lg border border-[#e8e4de] flex items-center justify-center text-xl hover:bg-[#f4f1ec] transition-colors font-light"
              >+</button>
              <span className="text-sm text-[#6b6b6b] me-2">
                المجموع: <strong className="text-[#0f5c35]">{(product.price * form.quantity).toLocaleString('ar-MA')} درهم</strong>
              </span>
            </div>
          </div>

          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">
              الاسم الكامل <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="مثال: محمد أمين"
              className={`w-full h-11 px-4 rounded-xl border text-sm focus:outline-none focus:ring-1 transition-colors ${
                errors.name ? 'border-red-400 focus:ring-red-400' : 'border-[#e8e4de] focus:border-[#0f5c35] focus:ring-[#0f5c35]'
              }`}
            />
            {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
          </div>

          {/* Phone */}
          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">
              رقم الهاتف <span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              value={form.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
              placeholder="06XXXXXXXX"
              className={`w-full h-11 px-4 rounded-xl border text-sm focus:outline-none focus:ring-1 transition-colors ${
                errors.phone ? 'border-red-400 focus:ring-red-400' : 'border-[#e8e4de] focus:border-[#0f5c35] focus:ring-[#0f5c35]'
              }`}
            />
            {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
          </div>

          {/* City */}
          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">
              المدينة <span className="text-red-500">*</span>
            </label>
            <select
              value={form.city}
              onChange={(e) => handleChange('city', e.target.value)}
              className={`w-full h-11 px-4 rounded-xl border text-sm focus:outline-none focus:ring-1 bg-white transition-colors ${
                errors.city ? 'border-red-400 focus:ring-red-400' : 'border-[#e8e4de] focus:border-[#0f5c35] focus:ring-[#0f5c35]'
              }`}
            >
              <option value="">اختر مدينتك</option>
              {['الدار البيضاء','الرباط','مراكش','فاس','طنجة','أكادير','مكناس','وجدة','القنيطرة','تطوان','سلا','الجديدة','بني ملال','خريبكة','سطات','العيون','الناظور','الحسيمة','تازة','الدار البيضاء الكبرى'].map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            {errors.city && <p className="text-red-500 text-xs mt-1">{errors.city}</p>}
          </div>

          {/* Address */}
          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">العنوان بالتفصيل</label>
            <input
              type="text"
              value={form.address}
              onChange={(e) => handleChange('address', e.target.value)}
              placeholder="الحي، الشارع، رقم المنزل..."
              className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] transition-colors"
            />
          </div>

          {/* Note */}
          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">ملاحظة (اختياري)</label>
            <textarea
              value={form.note}
              onChange={(e) => handleChange('note', e.target.value)}
              placeholder="أي معلومة إضافية..."
              rows={2}
              className="w-full px-4 py-3 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] transition-colors resize-none"
            />
          </div>
        </div>

        {/* Footer actions */}
        <div className="sticky bottom-0 bg-white border-t border-[#e8e4de] px-5 py-4">
          <button
            onClick={handleOrder}
            className="w-full flex items-center justify-center gap-2 bg-[#25D366] text-white font-bold py-4 rounded-xl hover:bg-[#1fb558] transition-colors text-base shadow-lg"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            أرسل طلبك عبر واتساب
          </button>
          <p className="text-xs text-center text-[#6b6b6b] mt-2">سيتم فتح واتساب لإتمام طلبك</p>
        </div>
      </div>
    </div>
  )
}
