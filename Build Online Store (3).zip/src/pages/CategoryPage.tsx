import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import ProductCard from '../components/ProductCard'
import EmptyState from '../components/EmptyState'
import WhatsAppOrderModal from '../components/WhatsAppOrderModal'
import type { Product } from '../types'

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>()
  const { getCategoryBySlug, getProductsByCategory } = useStore()
  const [orderProduct, setOrderProduct] = useState<Product | null>(null)

  const category = slug ? getCategoryBySlug(slug) : null

  if (!category) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-20 text-center">
        <div className="w-16 h-16 rounded-full bg-[#f4f1ec] flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-[#b0a99e]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h1 className="text-2xl font-bold text-[#111] mb-2">التصنيف غير موجود</h1>
        <p className="text-[#6b6b6b] mb-6">التصنيف الذي تبحث عنه غير متوفر أو تم حذفه</p>
        <Link to="/" className="inline-flex items-center gap-2 bg-[#0f5c35] text-white font-semibold px-5 py-2.5 rounded-lg hover:bg-[#0a4a2a] transition-colors">
          العودة للرئيسية
        </Link>
      </div>
    )
  }

  const categoryProducts = getProductsByCategory(category.id)

  return (
    <div>
      {/* Category hero */}
      <div className="relative bg-[#111] text-white overflow-hidden">
        {category.image_url && (
          <img
            src={category.image_url}
            alt={category.name}
            className="absolute inset-0 w-full h-full object-cover opacity-30"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-black/60" />
        <div className="relative max-w-6xl mx-auto px-4 py-12">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-white/60 mb-4">
            <Link to="/" className="hover:text-white transition-colors">الرئيسية</Link>
            <span>/</span>
            <span className="text-white">{category.name}</span>
          </nav>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{category.name}</h1>
          {category.description && (
            <p className="text-white/70 text-base max-w-xl">{category.description}</p>
          )}
          <p className="text-white/50 text-sm mt-2">{categoryProducts.length} منتج</p>
        </div>
      </div>

      {/* Products */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {categoryProducts.length === 0 ? (
          <EmptyState
            title="لا توجد منتجات في هذا التصنيف"
            description="لم يتم إضافة منتجات لهذا التصنيف بعد. تفقد التصنيفات الأخرى."
            action={{ label: 'تصفح جميع التصنيفات', onClick: () => window.history.back() }}
          />
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categoryProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                category={category}
                onOrder={setOrderProduct}
              />
            ))}
          </div>
        )}
      </div>

      <WhatsAppOrderModal product={orderProduct} onClose={() => setOrderProduct(null)} />
    </div>
  )
}
