import { createContext, useContext, useState, type ReactNode } from 'react'
import type { Category, Product, StoreSettings } from '../types'
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS, INITIAL_SETTINGS } from '../data/mock'

interface StoreContextType {
  products: Product[]
  categories: Category[]
  settings: StoreSettings
  isAdminAuthenticated: boolean
  setProducts: (p: Product[]) => void
  setCategories: (c: Category[]) => void
  setSettings: (s: StoreSettings) => void
  addProduct: (p: Product) => void
  updateProduct: (p: Product) => void
  deleteProduct: (id: string) => void
  addCategory: (c: Category) => void
  updateCategory: (c: Category) => void
  deleteCategory: (id: string) => void
  login: (email: string, password: string) => boolean
  logout: () => void
  getFeaturedProduct: () => Product | null
  getProductsByCategory: (categoryId: string) => Product[]
  getProductBySlug: (slug: string) => Product | null
  getCategoryBySlug: (slug: string) => Category | null
  searchProducts: (query: string) => Product[]
  cartCount: number
  cart: Record<string, number>
  addToCart: (productId: string, qty?: number) => void
  updateCartQuantity: (productId: string, qty: number) => void
  removeFromCart: (productId: string) => void
}

const StoreContext = createContext<StoreContextType | null>(null)

const ADMIN_EMAIL = 'admin@alipack.ma'
const ADMIN_PASSWORD = 'alipack2024'
const AUTH_KEY = 'alipack_admin_auth'

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS)
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES)
  const [settings, setSettings] = useState<StoreSettings>(INITIAL_SETTINGS)
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(
    () => sessionStorage.getItem(AUTH_KEY) === 'true'
  )

  const [cart, setCart] = useState<Record<string, number>>({})
  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0)
  function addToCart(productId: string, qty = 1) {
    setCart((prev) => ({ ...prev, [productId]: (prev[productId] ?? 0) + qty }))
  }

  function updateCartQuantity(productId: string, qty: number) {
    setCart((prev) => {
      if (qty <= 0) {
        const { [productId]: _removed, ...remaining } = prev
        return remaining
      }
      return { ...prev, [productId]: qty }
    })
  }

  function removeFromCart(productId: string) {
    setCart((prev) => {
      const { [productId]: _removed, ...remaining } = prev
      return remaining
    })
  }

  function addProduct(p: Product) {
    setProducts((prev) => [p, ...prev])
  }

  function updateProduct(p: Product) {
    setProducts((prev) => prev.map((x) => (x.id === p.id ? p : x)))
  }

  function deleteProduct(id: string) {
    setProducts((prev) => prev.filter((x) => x.id !== id))
  }

  function addCategory(c: Category) {
    setCategories((prev) => [c, ...prev])
  }

  function updateCategory(c: Category) {
    setCategories((prev) => prev.map((x) => (x.id === c.id ? c : x)))
  }

  function deleteCategory(id: string) {
    setCategories((prev) => prev.filter((x) => x.id !== id))
  }

  function login(email: string, password: string): boolean {
    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      sessionStorage.setItem(AUTH_KEY, 'true')
      setIsAdminAuthenticated(true)
      return true
    }
    return false
  }

  function logout() {
    sessionStorage.removeItem(AUTH_KEY)
    setIsAdminAuthenticated(false)
  }

  function getFeaturedProduct(): Product | null {
    if (!settings.featured_product_id) return null
    return products.find((p) => p.id === settings.featured_product_id) ?? null
  }

  function getProductsByCategory(categoryId: string): Product[] {
    return products.filter((p) => p.category_id === categoryId && p.in_stock !== false)
  }

  function getProductBySlug(slug: string): Product | null {
    return products.find((p) => p.slug === slug) ?? null
  }

  function getCategoryBySlug(slug: string): Category | null {
    return categories.find((c) => c.slug === slug) ?? null
  }

  function searchProducts(query: string): Product[] {
    const q = query.toLowerCase().trim()
    if (!q) return []
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        categories
          .find((c) => c.id === p.category_id)
          ?.name.toLowerCase()
          .includes(q)
    )
  }

  return (
    <StoreContext.Provider
      value={{
        products,
        categories,
        settings,
        isAdminAuthenticated,
        setProducts,
        setCategories,
        setSettings,
        addProduct,
        updateProduct,
        deleteProduct,
        addCategory,
        updateCategory,
        deleteCategory,
        login,
        logout,
        getFeaturedProduct,
        getProductsByCategory,
        getProductBySlug,
        getCategoryBySlug,
        searchProducts,
        cart,
        cartCount,
        addToCart,
        updateCartQuantity,
        removeFromCart,
      }}
    >
      {children}
    </StoreContext.Provider>
  )
}

export function useStore() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore must be used within StoreProvider')
  return ctx
}
