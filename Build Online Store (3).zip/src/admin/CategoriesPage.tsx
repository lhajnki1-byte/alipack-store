import { useState } from 'react'
import { useStore } from '../context/StoreContext'
import type { Category } from '../types'

const EMPTY: Omit<Category, 'id' | 'created_at'> = {
  name: '',
  slug: '',
  description: '',
  image_url: null,
}

function slugify(text: string) {
  return text
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '') || `category-${Date.now()}`
}

export default function CategoriesPage() {
  const { categories, products, addCategory, updateCategory, deleteCategory } = useStore()
  const [editing, setEditing] = useState<Category | null>(null)
  const [isNew, setIsNew] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState('')

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 3000)
  }

  function openNew() {
    setEditing({ ...EMPTY, id: '', created_at: new Date().toISOString() })
    setIsNew(true)
  }

  function openEdit(c: Category) {
    setEditing({ ...c })
    setIsNew(false)
  }

  async function handleSave() {
    if (!editing || !editing.name.trim()) return
    setSaving(true)
    await new Promise((r) => setTimeout(r, 300))
    const slug = editing.slug.trim() || slugify(editing.name)
    const cat: Category = { ...editing, slug, id: editing.id || `cat-${Date.now()}`, created_at: editing.created_at || new Date().toISOString() }
    if (isNew) {
      addCategory(cat)
      showToast('تم إضافة التصنيف')
    } else {
      updateCategory(cat)
      showToast('تم تحديث التصنيف')
    }
    setSaving(false)
    setEditing(null)
  }

  function handleDelete() {
    if (!deleteId) return
    deleteCategory(deleteId)
    setDeleteId(null)
    showToast('تم حذف التصنيف')
  }

  return (
    <div className="p-6 max-w-3xl">
      {toast && (
        <div className="fixed top-4 start-4 z-50 bg-[#0f5c35] text-white text-sm font-medium px-4 py-3 rounded-xl shadow-lg">
          ✓ {toast}
        </div>
      )}

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#111]">التصنيفات</h1>
          <p className="text-sm text-[#6b6b6b]">{categories.length} تصنيف</p>
        </div>
        <button
          onClick={openNew}
          className="flex items-center gap-2 bg-[#0f5c35] text-white font-semibold px-4 py-2.5 rounded-xl hover:bg-[#0a4a2a] transition-colors text-sm"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          تصنيف جديد
        </button>
      </div>

      <div className="space-y-3">
        {categories.map((cat) => {
          const count = products.filter((p) => p.category_id === cat.id).length
          return (
            <div key={cat.id} className="bg-white rounded-xl border border-[#e8e4de] p-4 flex items-center gap-4">
              {cat.image_url ? (
                <img src={cat.image_url} alt={cat.name} className="w-14 h-14 rounded-lg object-cover bg-[#f4f1ec] flex-shrink-0" />
              ) : (
                <div className="w-14 h-14 rounded-lg bg-[#f4f1ec] flex-shrink-0 flex items-center justify-center text-[#b0a99e]">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-[#111]">{cat.name}</p>
                <p className="text-xs text-[#6b6b6b] font-mono">{cat.slug}</p>
                {cat.description && <p className="text-xs text-[#6b6b6b] mt-0.5 truncate">{cat.description}</p>}
              </div>
              <span className="text-sm text-[#6b6b6b] flex-shrink-0">{count} منتج</span>
              <div className="flex items-center gap-1 flex-shrink-0">
                <button onClick={() => openEdit(cat)} className="p-1.5 rounded-lg hover:bg-[#f4f1ec] text-[#6b6b6b] hover:text-[#111] transition-colors">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                </button>
                <button onClick={() => setDeleteId(cat.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-[#6b6b6b] hover:text-red-600 transition-colors">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            </div>
          )
        })}

        {categories.length === 0 && (
          <div className="text-center py-14 text-[#6b6b6b]">
            <p className="font-medium">لا توجد تصنيفات بعد</p>
            <p className="text-sm mt-1">أضف أول تصنيف لمتجرك</p>
          </div>
        )}
      </div>

      {/* Edit modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEditing(null)} />
          <div className="relative bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="font-bold text-lg text-[#111]">{isNew ? 'تصنيف جديد' : 'تعديل التصنيف'}</h3>

            <div>
              <label className="block text-sm font-medium text-[#111] mb-1.5">اسم التصنيف <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={editing.name}
                onChange={(e) => setEditing({ ...editing, name: e.target.value, slug: slugify(e.target.value) })}
                className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[#111] mb-1.5">Slug</label>
              <input
                type="text"
                value={editing.slug}
                onChange={(e) => setEditing({ ...editing, slug: e.target.value })}
                className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] font-mono"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[#111] mb-1.5">الوصف</label>
              <textarea
                value={editing.description}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                rows={2}
                className="w-full px-4 py-3 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[#111] mb-1.5">رابط الصورة</label>
              <input
                type="url"
                value={editing.image_url ?? ''}
                onChange={(e) => setEditing({ ...editing, image_url: e.target.value || null })}
                placeholder="https://..."
                className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={handleSave}
                disabled={saving || !editing.name.trim()}
                className="flex-1 h-11 bg-[#0f5c35] text-white font-semibold rounded-xl hover:bg-[#0a4a2a] transition-colors disabled:opacity-60"
              >
                {saving ? 'جار الحفظ...' : isNew ? 'إضافة' : 'حفظ'}
              </button>
              <button onClick={() => setEditing(null)} className="px-5 h-11 border border-[#e8e4de] font-semibold rounded-xl hover:bg-[#f4f1ec] transition-colors text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete confirm */}
      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteId(null)} />
          <div className="relative bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl">
            <h3 className="font-bold text-lg text-[#111] mb-2">حذف التصنيف</h3>
            <p className="text-sm text-[#6b6b6b] mb-6">هل أنت متأكد من حذف هذا التصنيف؟ لا يمكن التراجع عن هذا الإجراء.</p>
            <div className="flex gap-3">
              <button onClick={handleDelete} className="flex-1 bg-red-600 text-white font-semibold py-2.5 rounded-xl hover:bg-red-700 text-sm">حذف</button>
              <button onClick={() => setDeleteId(null)} className="flex-1 border border-[#e8e4de] font-semibold py-2.5 rounded-xl hover:bg-[#f4f1ec] text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
