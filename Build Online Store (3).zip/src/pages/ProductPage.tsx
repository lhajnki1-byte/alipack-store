import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import ProductCard from '../components/ProductCard'
import WhatsAppOrderModal from '../components/WhatsAppOrderModal'
import type { Product } from '../types'

export default function ProductPage() {
  const { slug } = useParams<{ slug: string }>()
  const { getProductBySlug, products, categories, addToCart } = useStore()
  const [orderProduct, setOrderProduct] = useState<Product | null>(null)
  const [activeImage, setActiveImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [tab, setTab] = useState<'description' | 'specs'>('description')

  const product = slug ? getProductBySlug(slug) : null
  const category = product ? categories.find((c) => c.id === product.category_id) : null
  const related = product
    ? products.filter((p) => p.category_id === product.category_id && p.id !== product.id && p.in_stock).slice(0, 4)
    : []

  if (!product) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-20 text-center">
        <div className="w-16 h-16 rounded-full bg-[#f4f1ec] flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-[#b0a99e]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h1 className="text-2xl font-bold text-[#111] mb-2">المنتج غير موجود</h1>
        <p className="text-[#6b6b6b] mb-6">المنتج الذي تبحث عنه غير متوفر أو تم حذفه</p>
        <Link to="/" className="inline-flex items-center gap-2 bg-[#0f5c35] text-white font-semibold px-5 py-2.5 rounded-lg hover:bg-[#0a4a2a] transition-colors">
          العودة للرئيسية
        </Link>
      </div>
    )
  }

  const discount = product.compare_at_price
    ? Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)
    : 0

  function handleOrderWithQuantity() {
    setOrderProduct(product)
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-[#6b6b6b] mb-6">
        <Link to="/" className="hover:text-[#0f5c35] transition-colors">الرئيسية</Link>
        {category && (
          <>
            <span>/</span>
            <Link to={`/category/${category.slug}`} className="hover:text-[#0f5c35] transition-colors">{category.name}</Link>
          </>
        )}
        <span>/</span>
        <span className="text-[#111] font-medium line-clamp-1">{product.name}</span>
      </nav>

      {/* Product layout */}
      <div className="grid md:grid-cols-2 gap-8 lg:gap-12 mb-12">
        {/* Gallery */}
        <div className="space-y-3">
          {/* Main image */}
          <div className="aspect-square rounded-2xl overflow-hidden bg-[#f4f1ec] relative">
            {product.images[activeImage] ? (
              <img
                src={product.images[activeImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <svg className="w-16 h-16 text-[#d4cfc8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10" />
                </svg>
              </div>
            )}
            {/* Badges */}
            <div className="absolute top-3 start-3 flex flex-col gap-1.5">
              {product.is_featured && (
                <span className="bg-[#c49a2a] text-white text-xs font-bold px-2.5 py-1 rounded-full">⭐ مميز</span>
              )}
              {discount > 0 && (
                <span className="bg-red-500 text-white text-xs font-bold px-2.5 py-1 rounded-full">-{discount}%</span>
              )}
              {!product.in_stock && (
                <span className="bg-gray-500 text-white text-xs font-bold px-2.5 py-1 rounded-full">نفد المخزون</span>
              )}
            </div>
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                    i === activeImage ? 'border-[#0f5c35]' : 'border-transparent hover:border-[#c8c3bc]'
                  }`}
                >
                  <img src={img} alt={`صورة ${i + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product info */}
        <div>
          {category && (
            <Link to={`/category/${category.slug}`} className="text-xs font-semibold text-[#0f5c35] uppercase tracking-wider mb-2 block hover:underline">
              {category.name}
            </Link>
          )}
          <h1 className="text-2xl md:text-3xl font-bold text-[#111] mb-3 leading-tight">{product.name}</h1>

          {/* Price */}
          <div className="flex items-baseline gap-3 mb-5">
            <span className="text-3xl font-bold text-[#0f5c35]">{product.price.toLocaleString('ar-MA')} درهم</span>
            {product.compare_at_price && (
              <span className="text-lg text-[#999] line-through">{product.compare_at_price.toLocaleString('ar-MA')} درهم</span>
            )}
            {discount > 0 && (
              <span className="text-sm font-semibold text-red-500 bg-red-50 px-2 py-0.5 rounded">وفر {discount}%</span>
            )}
          </div>

          {/* Stock */}
          <div className={`inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-full mb-5 ${
            product.in_stock ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'
          }`}>
            <span className={`w-2 h-2 rounded-full ${product.in_stock ? 'bg-green-500' : 'bg-red-400'}`} />
            {product.in_stock ? 'متوفر في المخزون' : 'نفد المخزون'}
          </div>

          {/* Quantity + Order */}
          {product.in_stock && (
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium text-[#111]">الكمية:</span>
                <div className="flex items-center gap-2 border border-[#e8e4de] rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-9 h-9 flex items-center justify-center text-lg hover:bg-[#f4f1ec] transition-colors rounded-s-lg"
                  >−</button>
                  <span className="w-8 text-center font-semibold text-[#111]">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-9 h-9 flex items-center justify-center text-lg hover:bg-[#f4f1ec] transition-colors rounded-e-lg"
                  >+</button>
                </div>
                <span className="text-sm text-[#6b6b6b]">
                  المجموع: <strong className="text-[#0f5c35]">{(product.price * quantity).toLocaleString('ar-MA')} درهم</strong>
                </span>
              </div>

              <button
                onClick={() => addToCart(product.id, quantity)}
                className="w-full bg-[#0f5c35] text-white font-bold py-4 rounded-xl hover:bg-[#0a4a2a] transition-colors text-base shadow-md"
              >
                أضف إلى السلة
              </button>
              <button
                onClick={handleOrderWithQuantity}
                className="w-full flex items-center justify-center gap-2 bg-[#25D366] text-white font-bold py-4 rounded-xl hover:bg-[#1fb558] transition-colors text-base shadow-md"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                اطلب عبر واتساب
              </button>
            </div>
          )}

          {/* Trust mini-badges */}
          <div className="grid grid-cols-2 gap-2 mb-6 p-4 bg-[#f5f0eb] rounded-xl">
            {[
              { icon: '🚚', text: 'توصيل لجميع المدن' },
              { icon: '💰', text: 'الدفع عند التسليم' },
              { icon: '🔄', text: 'إرجاع خلال 7 أيام' },
              { icon: '💬', text: 'دعم عبر واتساب' },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-2 text-xs text-[#444]">
                <span>{item.icon}</span>
                <span>{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs: Description + Specs */}
      <div className="mb-12">
        <div className="flex border-b border-[#e8e4de] mb-5">
          {(['description', 'specs'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-5 py-3 text-sm font-semibold border-b-2 transition-colors ${
                tab === t
                  ? 'border-[#0f5c35] text-[#0f5c35]'
                  : 'border-transparent text-[#6b6b6b] hover:text-[#111]'
              }`}
            >
              {t === 'description' ? 'الوصف' : 'المواصفات'}
            </button>
          ))}
        </div>

        {tab === 'description' && (
          <p className="text-[#444] leading-relaxed text-base max-w-2xl">{product.description}</p>
        )}

        {tab === 'specs' && (
          <div className="max-w-lg">
            {Object.keys(product.specifications).length === 0 ? (
              <p className="text-[#6b6b6b] text-sm">لا توجد مواصفات مضافة لهذا المنتج</p>
            ) : (
              <table className="w-full text-sm">
                <tbody>
                  {Object.entries(product.specifications).map(([key, value], i) => (
                    <tr key={key} className={i % 2 === 0 ? 'bg-[#f5f0eb]' : 'bg-white'}>
                      <td className="py-2.5 px-4 font-medium text-[#111] rounded-s-lg w-40">{key}</td>
                      <td className="py-2.5 px-4 text-[#444] rounded-e-lg">{value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>

      {/* Related products */}
      {related.length > 0 && (
        <div>
          <div className="flex items-center gap-3 mb-5">
            <div className="w-1 h-6 bg-[#0f5c35] rounded-full" />
            <h2 className="text-xl font-bold text-[#111]">منتجات ذات صلة</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} category={category ?? undefined} onOrder={setOrderProduct} />
            ))}
          </div>
        </div>
      )}

      <WhatsAppOrderModal product={orderProduct} onClose={() => setOrderProduct(null)} />
    </div>
  )
}
