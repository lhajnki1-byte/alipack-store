import { useState, useEffect } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import ProductCard from '../components/ProductCard'
import EmptyState from '../components/EmptyState'
import WhatsAppOrderModal from '../components/WhatsAppOrderModal'
import type { Product } from '../types'

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const { searchProducts, categories } = useStore()
  const [orderProduct, setOrderProduct] = useState<Product | null>(null)
  const [inputValue, setInputValue] = useState(searchParams.get('q') ?? '')

  const query = searchParams.get('q') ?? ''
  const results = query ? searchProducts(query) : []

  useEffect(() => {
    setInputValue(query)
  }, [query])

  function handleSearch(e: React.FormEvent) {
    e.preventDefault()
    if (inputValue.trim()) {
      setSearchParams({ q: inputValue.trim() })
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-[#6b6b6b] mb-6">
        <Link to="/" className="hover:text-[#0f5c35] transition-colors">الرئيسية</Link>
        <span>/</span>
        <span className="text-[#111]">البحث</span>
      </nav>

      {/* Search bar */}
      <form onSubmit={handleSearch} className="mb-8">
        <div className="relative max-w-xl">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="ابحث عن منتج، تصنيف..."
            className="w-full h-12 px-5 pe-12 rounded-2xl border border-[#e8e4de] bg-white text-base focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] shadow-sm transition-colors"
            autoFocus
          />
          <button
            type="submit"
            className="absolute start-0 top-0 h-12 w-12 flex items-center justify-center text-[#0f5c35] hover:text-[#0a4a2a] transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </div>
      </form>

      {/* Results */}
      {!query ? (
        <div className="text-center py-16 text-[#6b6b6b]">
          <svg className="w-12 h-12 mx-auto mb-4 text-[#c8c3bc]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <p className="font-medium">ابحث عن منتجاتك المفضلة</p>
          <p className="text-sm mt-1">اكتب اسم المنتج أو التصنيف في مربع البحث</p>
        </div>
      ) : results.length === 0 ? (
        <EmptyState
          title={`لا توجد نتائج لـ "${query}"`}
          description="حاول البحث بكلمات أخرى أو تصفح التصنيفات"
          action={{ label: 'تصفح جميع المنتجات', onClick: () => window.location.href = '/' }}
        />
      ) : (
        <>
          <div className="flex items-center justify-between mb-5">
            <p className="text-sm text-[#6b6b6b]">
              <strong className="text-[#111]">{results.length}</strong> نتيجة لـ &ldquo;{query}&rdquo;
            </p>
            <button
              onClick={() => { setInputValue(''); setSearchParams({}) }}
              className="text-sm text-[#6b6b6b] hover:text-[#0f5c35] transition-colors"
            >
              مسح البحث
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {results.map((product) => {
              const cat = categories.find((c) => c.id === product.category_id)
              return (
                <ProductCard
                  key={product.id}
                  product={product}
                  category={cat}
                  onOrder={setOrderProduct}
                />
              )
            })}
          </div>
        </>
      )}

      <WhatsAppOrderModal product={orderProduct} onClose={() => setOrderProduct(null)} />
    </div>
  )
}
