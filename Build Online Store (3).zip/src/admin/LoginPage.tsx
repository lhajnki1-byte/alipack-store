import { useState } from 'react'
import { useNavigate, Navigate } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import BrandLogo from '../components/BrandLogo'

export default function LoginPage() {
  const { login, isAdminAuthenticated } = useStore()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (isAdminAuthenticated) return <Navigate to="/admin" replace />

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    await new Promise((r) => setTimeout(r, 500))
    const ok = login(email, password)
    setLoading(false)
    if (ok) {
      navigate('/admin', { replace: true })
    } else {
      setError('البريد الإلكتروني أو كلمة المرور غير صحيحة')
    }
  }

  return (
    <div className="min-h-screen bg-[#f5f0eb] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-3">
            <BrandLogo size="lg" showTagline={false} />
          </div>
          <p className="text-sm text-[#6b6b6b] mt-1">لوحة التحكم</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 shadow-sm border border-[#e8e4de] space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">البريد الإلكتروني</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@alipack.ma"
              required
              className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] transition-colors"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">كلمة المرور</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] transition-colors"
            />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 text-sm px-4 py-3 rounded-xl">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full h-11 bg-[#0f5c35] text-white font-semibold rounded-xl hover:bg-[#0a4a2a] transition-colors disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
            ) : null}
            {loading ? 'جار تسجيل الدخول...' : 'تسجيل الدخول'}
          </button>
        </form>

        <p className="text-center text-xs text-[#6b6b6b] mt-4">
          للعودة للمتجر —{' '}
          <a href="/" className="text-[#0f5c35] hover:underline">الرئيسية</a>
        </p>
      </div>
    </div>
  )
}
