import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { StoreProvider } from './context/StoreContext'
import Header from './components/Header'
import Footer from './components/Footer'

import HomePage from './pages/HomePage'
import CategoryPage from './pages/CategoryPage'
import ProductPage from './pages/ProductPage'
import SearchPage from './pages/SearchPage'
import CartPage from './pages/CartPage'
import NotFoundPage from './pages/NotFoundPage'

import LoginPage from './admin/LoginPage'
import AdminLayout from './admin/AdminLayout'
import DashboardPage from './admin/DashboardPage'
import ProductsPage from './admin/ProductsPage'
import CategoriesPage from './admin/CategoriesPage'
import SettingsPage from './admin/SettingsPage'

function StorefrontLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-white" dir="rtl">
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  )
}

export default function App() {
  return (
    <StoreProvider>
    <BrowserRouter>
      <Routes>
          {/* Public storefront */}
          <Route
            path="/"
            element={
              <StorefrontLayout>
                <HomePage />
              </StorefrontLayout>
            }
          />
          <Route
            path="/category/:slug"
            element={
              <StorefrontLayout>
                <CategoryPage />
              </StorefrontLayout>
            }
          />
          <Route
            path="/product/:slug"
            element={
              <StorefrontLayout>
                <ProductPage />
              </StorefrontLayout>
            }
          />
          <Route
            path="/search"
            element={
              <StorefrontLayout>
                <SearchPage />
              </StorefrontLayout>
            }
          />
          <Route
            path="/cart"
            element={<CartPage />}
          />

          {/* Auth */}
          <Route path="/login" element={<LoginPage />} />

          {/* Admin */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<DashboardPage />} />
            <Route path="products" element={<ProductsPage />} />
            <Route path="categories" element={<CategoriesPage />} />
            <Route path="settings" element={<SettingsPage />} />
          </Route>

          {/* 404 */}
          <Route
            path="*"
            element={
              <StorefrontLayout>
                <NotFoundPage />
              </StorefrontLayout>
            }
          />
      </Routes>
    </BrowserRouter>
    </StoreProvider>
  )
}
