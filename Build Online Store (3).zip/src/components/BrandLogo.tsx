type BrandLogoProps = {
  size?: 'sm' | 'md' | 'lg'
  variant?: 'default' | 'inverse'
  showTagline?: boolean
}

const sizes = {
  sm: { icon: 'w-8 h-8', wordmark: 'text-[17px]', tagline: 'text-[7px]' },
  md: { icon: 'w-10 h-10', wordmark: 'text-[21px]', tagline: 'text-[8px]' },
  lg: { icon: 'w-14 h-14', wordmark: 'text-[28px]', tagline: 'text-[9px]' },
}

/** The compact primary lockup, designed to remain clear in a mobile header. */
export default function BrandLogo({ size = 'md', variant = 'default', showTagline = true }: BrandLogoProps) {
  const scale = sizes[size]
  const textColor = variant === 'inverse' ? 'text-white' : 'text-[#10261b]'
  const mutedColor = variant === 'inverse' ? 'text-white/60' : 'text-[#0f5c35]/65'

  return (
    <div className="inline-flex items-center gap-2.5 leading-none" dir="ltr" aria-label="Ali Bak">
      <svg className={`${scale.icon} shrink-0`} viewBox="0 0 48 48" role="img" aria-hidden="true">
        <path d="M24 3.5 42 12.7v21.6L24 44.5 6 34.3V12.7L24 3.5Z" fill="#0f5c35" />
        <path d="M24 3.5v20.8m18-11.6L24 24.3 6 12.7M24 24.3v20.2" fill="none" stroke="#fffaf0" strokeWidth="2.2" strokeLinejoin="round" />
        <path d="m30.3 7.6 6.2 3.2-18 11.5-6.1-3.4 18-11.5Z" fill="#c49a2a" />
        <path d="M24 3.5 42 12.7v21.6L24 44.5" fill="none" stroke="#093d23" strokeWidth="1.2" strokeLinejoin="round" opacity=".6" />
      </svg>
      <span className="flex flex-col gap-1 pt-0.5">
        <span className={`brand-wordmark ${scale.wordmark} ${textColor}`}>Ali <b>Bak</b></span>
        {showTagline && <span className={`brand-tagline ${scale.tagline} ${mutedColor}`}>PACKAGING SUPPLY</span>}
      </span>
    </div>
  )
}
