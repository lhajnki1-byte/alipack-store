import { Link } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import type { Product, Category } from '../types'

interface Props {
  product: Product
  category?: Category
  onOrder?: (product: Product) => void
  size?: 'normal' | 'featured'
}

export default function ProductCard({ product, category, onOrder, size = 'normal' }: Props) {
  const { addToCart } = useStore()
  const discount = product.compare_at_price
    ? Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)
    : 0

  if (size === 'featured') {
    return (
      <div className="relative bg-white rounded-2xl overflow-hidden shadow-lg border border-[#e8e4de] group">
        <div className="grid md:grid-cols-2 gap-0">
          {/* Image */}
          <div className="relative aspect-square md:aspect-auto bg-[#f4f1ec] overflow-hidden">
            {product.images[0] ? (
              <img
                src={product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <svg className="w-16 h-16 text-[#d4cfc8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10" />
                </svg>
              </div>
            )}
            {/* Badges */}
            <div className="absolute top-3 start-3 flex flex-col gap-1.5">
              <span className="bg-[#c49a2a] text-white text-xs font-bold px-2.5 py-1 rounded-full">⭐ منتج مميز</span>
              {discount > 0 && (
                <span className="bg-red-500 text-white text-xs font-bold px-2.5 py-1 rounded-full">-{discount}%</span>
              )}
            </div>
          </div>

          {/* Content */}
          <div className="p-6 md:p-8 flex flex-col justify-center">
            {category && (
              <Link
                to={`/category/${category.slug}`}
                className="text-xs font-semibold text-[#0f5c35] uppercase tracking-wider mb-2 hover:underline"
              >
                {category.name}
              </Link>
            )}
            <h2 className="text-xl md:text-2xl font-bold text-[#111] mb-3 leading-tight">{product.name}</h2>
            <p className="text-sm text-[#6b6b6b] leading-relaxed mb-5 line-clamp-3">{product.description}</p>

            <div className="flex items-baseline gap-3 mb-6">
              <span className="text-3xl font-bold text-[#0f5c35]">{product.price.toLocaleString('ar-MA')} درهم</span>
              {product.compare_at_price && (
                <span className="text-lg text-[#999] line-through">{product.compare_at_price.toLocaleString('ar-MA')} درهم</span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => addToCart(product.id)}
                className="flex-1 min-w-[140px] bg-[#0f5c35] text-white font-semibold py-3 px-4 rounded-xl hover:bg-[#0a4a2a] transition-colors text-sm"
              >
                أضف إلى السلة
              </button>
              <button
                onClick={() => onOrder?.(product)}
                className="flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-[#25D366] text-white font-semibold py-3 px-4 rounded-xl hover:bg-[#1fb558] transition-colors text-sm"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                اطلب عبر واتساب
              </button>
              <Link
                to={`/product/${product.slug}`}
                className="px-4 py-3 border border-[#0f5c35] text-[#0f5c35] font-semibold rounded-xl hover:bg-[#0f5c35] hover:text-white transition-colors text-sm"
              >
                التفاصيل
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-xl overflow-hidden border border-[#e8e4de] group hover:shadow-md transition-shadow">
      {/* Image */}
      <Link to={`/product/${product.slug}`} className="block relative aspect-square bg-[#f4f1ec] overflow-hidden">
        {product.images[0] ? (
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-400"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <svg className="w-12 h-12 text-[#d4cfc8]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10" />
            </svg>
          </div>
        )}

        {/* Badges */}
        <div className="absolute top-2 start-2 flex flex-col gap-1">
          {product.is_featured && (
            <span className="bg-[#c49a2a] text-white text-xs font-bold px-2 py-0.5 rounded-full">مميز</span>
          )}
          {discount > 0 && (
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">-{discount}%</span>
          )}
          {!product.in_stock && (
            <span className="bg-gray-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">نفد المخزون</span>
          )}
        </div>
      </Link>

      {/* Content */}
      <div className="p-4">
        {category && (
          <Link to={`/category/${category.slug}`} className="text-xs text-[#0f5c35] font-medium hover:underline block mb-1">
            {category.name}
          </Link>
        )}
        <Link to={`/product/${product.slug}`}>
          <h3 className="font-semibold text-[#111] text-sm leading-snug mb-1 line-clamp-2 hover:text-[#0f5c35] transition-colors">
            {product.name}
          </h3>
        </Link>

        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-base font-bold text-[#0f5c35]">{product.price.toLocaleString('ar-MA')} د.م</span>
          {product.compare_at_price && (
            <span className="text-xs text-[#999] line-through">{product.compare_at_price.toLocaleString('ar-MA')}</span>
          )}
        </div>

        <div className="flex flex-col gap-2">
          <button
            onClick={() => addToCart(product.id)}
            disabled={!product.in_stock}
            className={`w-full py-2.5 px-3 rounded-lg text-sm font-semibold transition-colors ${
              product.in_stock ? 'bg-[#0f5c35] text-white hover:bg-[#0a4a2a]' : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }`}
          >
            أضف إلى السلة
          </button>
        <button
          onClick={() => onOrder?.(product)}
          disabled={!product.in_stock}
          className={`w-full flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-lg text-xs font-semibold transition-colors ${
            product.in_stock
              ? 'bg-[#25D366] text-white hover:bg-[#1fb558]'
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
          }`}
        >
          {product.in_stock ? (
            <>
              <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              اطلب عبر واتساب
            </>
          ) : 'نفد المخزون'}
        </button>
        </div>
      </div>
    </div>
  )
}
