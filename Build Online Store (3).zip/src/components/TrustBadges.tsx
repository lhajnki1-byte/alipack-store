import { useStore } from '../context/StoreContext'

const badges = [
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
    ),
    title: 'الدفع عند التسليم',
    settingKey: 'cod_text' as const,
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
      </svg>
    ),
    title: 'توصيل سريع',
    settingKey: 'delivery_text' as const,
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
      </svg>
    ),
    title: 'إرجاع سهل',
    settingKey: 'return_text' as const,
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
      </svg>
    ),
    title: 'دعم العملاء',
    settingKey: 'support_text' as const,
  },
]

export default function TrustBadges() {
  const { settings } = useStore()

  return (
    <section className="border-y border-[#e8e4de] bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-x-reverse divide-[#e8e4de]">
          {badges.map((badge) => (
            <div key={badge.settingKey} className="flex flex-col sm:flex-row items-center sm:items-start gap-3 px-4 py-6">
              <div className="w-10 h-10 rounded-lg bg-[#0f5c35]/8 flex items-center justify-center text-[#0f5c35] flex-shrink-0">
                {badge.icon}
              </div>
              <div className="text-center sm:text-start">
                <p className="font-semibold text-sm text-[#111]">{badge.title}</p>
                <p className="text-xs text-[#6b6b6b] leading-relaxed mt-0.5 line-clamp-2">{settings[badge.settingKey]}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
