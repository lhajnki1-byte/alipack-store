import { useState } from 'react'
import { useStore } from '../context/StoreContext'
import type { Product } from '../types'

const EMPTY_PRODUCT: Omit<Product, 'id' | 'created_at'> = {
  name: '',
  slug: '',
  description: '',
  price: 0,
  compare_at_price: null,
  category_id: '',
  images: [],
  is_featured: false,
  in_stock: true,
  specifications: {},
}

function slugify(text: string) {
  return text
    .toLowerCase()
    .replace(/[\s؀-ۿ]/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '') || `product-${Date.now()}`
}

export default function ProductsPage() {
  const { products, categories, addProduct, updateProduct, deleteProduct, settings } = useStore()
  const [search, setSearch] = useState('')
  const [editing, setEditing] = useState<Product | null>(null)
  const [isNew, setIsNew] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [specKey, setSpecKey] = useState('')
  const [specVal, setSpecVal] = useState('')
  const [imageUrl, setImageUrl] = useState('')
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState('')

  const filtered = products.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase())
  )

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 3000)
  }

  function openNew() {
    setEditing({ ...EMPTY_PRODUCT, id: '', created_at: new Date().toISOString() } as Product)
    setIsNew(true)
  }

  function openEdit(p: Product) {
    setEditing({ ...p })
    setIsNew(false)
  }

  function closeDrawer() {
    setEditing(null)
    setSpecKey('')
    setSpecVal('')
    setImageUrl('')
  }

  async function handleSave() {
    if (!editing) return
    if (!editing.name.trim()) return
    setSaving(true)
    await new Promise((r) => setTimeout(r, 300))
    const slug = editing.slug.trim() || slugify(editing.name)
    const product: Product = { ...editing, slug, id: editing.id || `prod-${Date.now()}`, created_at: editing.created_at || new Date().toISOString() }
    if (isNew) {
      addProduct(product)
      showToast('تم إضافة المنتج بنجاح')
    } else {
      updateProduct(product)
      showToast('تم تحديث المنتج بنجاح')
    }
    setSaving(false)
    closeDrawer()
  }

  function handleDelete() {
    if (!deleteId) return
    deleteProduct(deleteId)
    setDeleteId(null)
    showToast('تم حذف المنتج')
  }

  function addSpec() {
    if (!specKey.trim() || !specVal.trim() || !editing) return
    setEditing({ ...editing, specifications: { ...editing.specifications, [specKey]: specVal } })
    setSpecKey('')
    setSpecVal('')
  }

  function removeSpec(key: string) {
    if (!editing) return
    const s = { ...editing.specifications }
    delete s[key]
    setEditing({ ...editing, specifications: s })
  }

  function addImage() {
    if (!imageUrl.trim() || !editing) return
    setEditing({ ...editing, images: [...editing.images, imageUrl.trim()] })
    setImageUrl('')
  }

  function removeImage(i: number) {
    if (!editing) return
    setEditing({ ...editing, images: editing.images.filter((_, idx) => idx !== i) })
  }

  if (!editing) {
    return (
      <div className="p-6">
        {/* Toast */}
        {toast && (
          <div className="fixed top-4 start-4 z-50 bg-[#0f5c35] text-white text-sm font-medium px-4 py-3 rounded-xl shadow-lg">
            ✓ {toast}
          </div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-[#111]">المنتجات</h1>
            <p className="text-sm text-[#6b6b6b]">{products.length} منتج</p>
          </div>
          <button
            onClick={openNew}
            className="flex items-center gap-2 bg-[#0f5c35] text-white font-semibold px-4 py-2.5 rounded-xl hover:bg-[#0a4a2a] transition-colors text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            منتج جديد
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-5 max-w-sm">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث في المنتجات..."
            className="w-full h-10 px-4 pe-10 rounded-xl border border-[#e8e4de] bg-white text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
          />
          <svg className="absolute start-3 top-3 w-4 h-4 text-[#6b6b6b]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl border border-[#e8e4de] overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-[#f5f0eb] border-b border-[#e8e4de]">
              <tr>
                <th className="text-start px-4 py-3 font-semibold text-[#444] w-12">#</th>
                <th className="text-start px-4 py-3 font-semibold text-[#444]">المنتج</th>
                <th className="text-start px-4 py-3 font-semibold text-[#444] hidden md:table-cell">التصنيف</th>
                <th className="text-start px-4 py-3 font-semibold text-[#444]">السعر</th>
                <th className="text-start px-4 py-3 font-semibold text-[#444] hidden sm:table-cell">الحالة</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e8e4de]">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center text-[#6b6b6b]">لا توجد منتجات</td>
                </tr>
              ) : (
                filtered.map((product, i) => {
                  const cat = categories.find((c) => c.id === product.category_id)
                  return (
                    <tr key={product.id} className="hover:bg-[#fafaf8] transition-colors">
                      <td className="px-4 py-3 text-[#6b6b6b]">{i + 1}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          {product.images[0] ? (
                            <img src={product.images[0]} alt={product.name} className="w-10 h-10 rounded-lg object-cover bg-[#f4f1ec] flex-shrink-0" />
                          ) : (
                            <div className="w-10 h-10 rounded-lg bg-[#f4f1ec] flex-shrink-0" />
                          )}
                          <div className="min-w-0">
                            <p className="font-medium text-[#111] truncate max-w-[160px]">{product.name}</p>
                            {product.is_featured && (
                              <span className="text-xs text-[#9a7a1f] bg-[#c49a2a]/15 px-1.5 py-0.5 rounded">مميز</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-[#6b6b6b] hidden md:table-cell">{cat?.name ?? '—'}</td>
                      <td className="px-4 py-3 font-semibold text-[#0f5c35]">{product.price} د.م</td>
                      <td className="px-4 py-3 hidden sm:table-cell">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${product.in_stock ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>
                          {product.in_stock ? 'متوفر' : 'نفد'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => openEdit(product)}
                            className="p-1.5 rounded-lg hover:bg-[#f4f1ec] text-[#6b6b6b] hover:text-[#111] transition-colors"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                            </svg>
                          </button>
                          <button
                            onClick={() => setDeleteId(product.id)}
                            className="p-1.5 rounded-lg hover:bg-red-50 text-[#6b6b6b] hover:text-red-600 transition-colors"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Delete confirm modal */}
        {deleteId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteId(null)} />
            <div className="relative bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl">
              <h3 className="font-bold text-lg text-[#111] mb-2">حذف المنتج</h3>
              <p className="text-sm text-[#6b6b6b] mb-6">هل أنت متأكد من حذف هذا المنتج؟ لا يمكن التراجع عن هذا الإجراء.</p>
              <div className="flex gap-3">
                <button onClick={handleDelete} className="flex-1 bg-red-600 text-white font-semibold py-2.5 rounded-xl hover:bg-red-700 transition-colors text-sm">حذف</button>
                <button onClick={() => setDeleteId(null)} className="flex-1 border border-[#e8e4de] font-semibold py-2.5 rounded-xl hover:bg-[#f4f1ec] transition-colors text-sm">إلغاء</button>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  // Edit/Add drawer
  return (
    <div className="p-6 max-w-2xl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-7">
        <button onClick={closeDrawer} className="p-2 rounded-lg hover:bg-[#f4f1ec] transition-colors">
          <svg className="w-5 h-5 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
          </svg>
        </button>
        <h1 className="text-xl font-bold text-[#111]">{isNew ? 'منتج جديد' : 'تعديل المنتج'}</h1>
      </div>

      <div className="space-y-5">
        {/* Basic info */}
        <div className="bg-white rounded-xl border border-[#e8e4de] p-5 space-y-4">
          <h2 className="font-semibold text-sm text-[#111] uppercase tracking-wide">المعلومات الأساسية</h2>

          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">اسم المنتج <span className="text-red-500">*</span></label>
            <input
              type="text"
              value={editing.name}
              onChange={(e) => setEditing({ ...editing, name: e.target.value, slug: slugify(e.target.value) })}
              placeholder="اسم المنتج"
              className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">Slug (URL)</label>
            <input
              type="text"
              value={editing.slug}
              onChange={(e) => setEditing({ ...editing, slug: e.target.value })}
              className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] font-mono text-[#6b6b6b]"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">التصنيف</label>
            <select
              value={editing.category_id}
              onChange={(e) => setEditing({ ...editing, category_id: e.target.value })}
              className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] bg-white"
            >
              <option value="">بدون تصنيف</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#111] mb-1.5">الوصف</label>
            <textarea
              value={editing.description}
              onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              placeholder="وصف تفصيلي للمنتج..."
              rows={4}
              className="w-full px-4 py-3 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35] resize-none"
            />
          </div>
        </div>

        {/* Pricing */}
        <div className="bg-white rounded-xl border border-[#e8e4de] p-5 space-y-4">
          <h2 className="font-semibold text-sm text-[#111] uppercase tracking-wide">السعر</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#111] mb-1.5">السعر (درهم) <span className="text-red-500">*</span></label>
              <input
                type="number"
                min={0}
                value={editing.price}
                onChange={(e) => setEditing({ ...editing, price: parseFloat(e.target.value) || 0 })}
                className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#111] mb-1.5">سعر المقارنة</label>
              <input
                type="number"
                min={0}
                value={editing.compare_at_price ?? ''}
                onChange={(e) => setEditing({ ...editing, compare_at_price: e.target.value ? parseFloat(e.target.value) : null })}
                placeholder="اختياري"
                className="w-full h-11 px-4 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
              />
            </div>
          </div>
        </div>

        {/* Status */}
        <div className="bg-white rounded-xl border border-[#e8e4de] p-5 space-y-3">
          <h2 className="font-semibold text-sm text-[#111] uppercase tracking-wide">الحالة</h2>
          <label className="flex items-center justify-between cursor-pointer">
            <div>
              <p className="text-sm font-medium text-[#111]">متوفر في المخزون</p>
              <p className="text-xs text-[#6b6b6b]">يظهر في المتجر ويمكن طلبه</p>
            </div>
            <div
              onClick={() => setEditing({ ...editing, in_stock: !editing.in_stock })}
              className={`w-11 h-6 rounded-full transition-colors cursor-pointer ${editing.in_stock ? 'bg-[#0f5c35]' : 'bg-[#d4cfc8]'}`}
            >
              <div className={`w-5 h-5 bg-white rounded-full shadow mt-0.5 transition-transform ${editing.in_stock ? 'translate-x-0.5' : 'translate-x-5'}`} style={{ marginTop: 2, marginRight: editing.in_stock ? 2 : undefined, marginLeft: editing.in_stock ? undefined : 2 }} />
            </div>
          </label>
          <label className="flex items-center justify-between cursor-pointer">
            <div>
              <p className="text-sm font-medium text-[#111]">منتج مميز</p>
              <p className="text-xs text-[#6b6b6b]">يظهر في قسم المنتج المميز في الرئيسية</p>
            </div>
            <div
              onClick={() => setEditing({ ...editing, is_featured: !editing.is_featured })}
              className={`w-11 h-6 rounded-full transition-colors cursor-pointer ${editing.is_featured ? 'bg-[#c49a2a]' : 'bg-[#d4cfc8]'}`}
            >
              <div className={`w-5 h-5 bg-white rounded-full shadow mt-0.5 transition-transform ${editing.is_featured ? 'translate-x-0.5' : 'translate-x-5'}`} style={{ marginTop: 2, marginRight: editing.is_featured ? 2 : undefined, marginLeft: editing.is_featured ? undefined : 2 }} />
            </div>
          </label>
        </div>

        {/* Images */}
        <div className="bg-white rounded-xl border border-[#e8e4de] p-5 space-y-3">
          <h2 className="font-semibold text-sm text-[#111] uppercase tracking-wide">الصور</h2>
          {editing.images.length > 0 && (
            <div className="grid grid-cols-4 gap-2">
              {editing.images.map((img, i) => (
                <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-[#f4f1ec] group">
                  <img src={img} alt="" className="w-full h-full object-cover" />
                  {i === 0 && (
                    <span className="absolute top-1 start-1 text-xs bg-[#0f5c35] text-white px-1.5 py-0.5 rounded">رئيسية</span>
                  )}
                  <button
                    onClick={() => removeImage(i)}
                    className="absolute top-1 end-1 w-5 h-5 bg-red-600 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  >×</button>
                </div>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="رابط الصورة (URL)..."
              className="flex-1 h-10 px-3 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
            />
            <button onClick={addImage} className="px-3 h-10 bg-[#0f5c35] text-white rounded-xl hover:bg-[#0a4a2a] text-sm transition-colors">إضافة</button>
          </div>
        </div>

        {/* Specifications */}
        <div className="bg-white rounded-xl border border-[#e8e4de] p-5 space-y-3">
          <h2 className="font-semibold text-sm text-[#111] uppercase tracking-wide">المواصفات</h2>
          {Object.keys(editing.specifications).length > 0 && (
            <div className="space-y-1">
              {Object.entries(editing.specifications).map(([k, v]) => (
                <div key={k} className="flex items-center gap-2 bg-[#f5f0eb] px-3 py-2 rounded-lg">
                  <span className="font-medium text-sm text-[#111] w-24 flex-shrink-0">{k}</span>
                  <span className="text-sm text-[#444] flex-1">{v}</span>
                  <button onClick={() => removeSpec(k)} className="text-red-400 hover:text-red-600 transition-colors text-lg leading-none">×</button>
                </div>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <input
              type="text"
              value={specKey}
              onChange={(e) => setSpecKey(e.target.value)}
              placeholder="الخاصية (مثال: الوزن)"
              className="flex-1 h-10 px-3 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
            />
            <input
              type="text"
              value={specVal}
              onChange={(e) => setSpecVal(e.target.value)}
              placeholder="القيمة"
              className="flex-1 h-10 px-3 rounded-xl border border-[#e8e4de] text-sm focus:outline-none focus:border-[#0f5c35] focus:ring-1 focus:ring-[#0f5c35]"
            />
            <button onClick={addSpec} className="px-3 h-10 bg-[#0f5c35] text-white rounded-xl hover:bg-[#0a4a2a] text-sm transition-colors">+</button>
          </div>
        </div>

        {/* Save */}
        <div className="flex gap-3">
          <button
            onClick={handleSave}
            disabled={saving || !editing.name.trim()}
            className="flex-1 h-12 bg-[#0f5c35] text-white font-semibold rounded-xl hover:bg-[#0a4a2a] transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {saving && (
              <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
            )}
            {saving ? 'جار الحفظ...' : isNew ? 'إضافة المنتج' : 'حفظ التعديلات'}
          </button>
          <button onClick={closeDrawer} className="px-5 h-12 border border-[#e8e4de] font-semibold rounded-xl hover:bg-[#f4f1ec] transition-colors text-sm">إلغاء</button>
        </div>
      </div>
    </div>
  )
}
