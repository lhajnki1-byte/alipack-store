import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useStore } from '../context/StoreContext'
import ProductCard from '../components/ProductCard'
import TrustBadges from '../components/TrustBadges'
import WhatsAppOrderModal from '../components/WhatsAppOrderModal'
import type { Product } from '../types'

export default function HomePage() {
  const { products, categories, settings, getFeaturedProduct } = useStore()
  const [orderProduct, setOrderProduct] = useState<Product | null>(null)

  const featured = getFeaturedProduct()
  const featuredCategory = featured ? categories.find((c) => c.id === featured.category_id) : null
  const otherProducts = products.filter((p) => p.id !== featured?.id && p.in_stock)
  const whatsappUrl = `https://wa.me/${settings.whatsapp_number.replace(/\D/g, '')}`

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-[#0a1f14] text-white min-h-[480px] md:min-h-[580px] flex items-center">
        {settings.hero_image_url && (
          <div className="absolute inset-0">
            <img
              src={settings.hero_image_url}
              alt="فريق علي باك — جاهزون للتوصيل"
              className="w-full h-full object-cover opacity-30"
            />
            <div className="absolute inset-0 bg-gradient-to-e from-[#0a1f14]/95 via-[#0a1f14]/70 to-[#0a1f14]/30" />
          </div>
        )}

        <div className="relative max-w-6xl mx-auto px-4 py-16 md:py-24 w-full">
          <div className="max-w-2xl">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2 bg-[#c49a2a]/15 border border-[#c49a2a]/35 text-[#e8c55a] text-xs font-semibold px-3.5 py-1.5 rounded-full mb-6 tracking-wide">
              <span className="w-1.5 h-1.5 rounded-full bg-[#c49a2a] animate-pulse flex-shrink-0" />
              متاح في الدار البيضاء وجميع أنحاء المغرب
            </div>

            {/* Heading — Amiri for elegance */}
            <h1 className="font-['Amiri'] text-4xl md:text-6xl font-bold leading-snug mb-5 text-white">
              {settings.hero_title}
            </h1>

            <p className="text-base md:text-lg text-white/70 leading-relaxed mb-8 max-w-xl">
              {settings.hero_subtitle}
            </p>

            {/* CTA row */}
            <div className="flex flex-wrap items-center gap-3">
              <Link
                to="#catalog"
                onClick={(e) => {
                  e.preventDefault()
                  document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' })
                }}
                className="inline-flex items-center gap-2 bg-[#0f5c35] text-white font-semibold px-7 py-3.5 rounded-lg hover:bg-[#0d5230] transition-colors text-sm tracking-wide"
              >
                تصفح المنتجات
                <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </Link>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-transparent border border-white/30 text-white font-semibold px-7 py-3.5 rounded-lg hover:bg-white/10 transition-colors text-sm tracking-wide"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                واتساب
              </a>
            </div>
          </div>
        </div>

        {/* Decorative corner shape */}
        <div className="hidden md:block absolute bottom-0 end-0 w-72 h-72 bg-[#0f5c35]/15 rounded-full blur-3xl pointer-events-none" />
      </section>

      {/* Featured product */}
      {featured && (
        <section className="max-w-6xl mx-auto px-4 py-10">
          <div className="mb-6">
            <h2 className="section-heading text-2xl">Product of the Week</h2>
            <span className="section-heading-accent section-heading-accent-gold" />
          </div>
          <ProductCard
            product={featured}
            category={featuredCategory}
            onOrder={setOrderProduct}
            size="featured"
          />
        </section>
      )}

      {/* Trust badges */}
      <TrustBadges />

      {/* Categories */}
      <section className="max-w-6xl mx-auto px-4 py-10">
        <div className="mb-6">
          <h2 className="section-heading text-2xl">التصنيفات</h2>
          <span className="section-heading-accent" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((cat) => {
            const count = products.filter((p) => p.category_id === cat.id).length
            return (
              <Link
                key={cat.id}
                to={`/category/${cat.slug}`}
                className="group relative rounded-xl overflow-hidden aspect-[4/3] bg-[#f4f1ec] block"
              >
                {cat.image_url && (
                  <img
                    src={cat.image_url}
                    alt={cat.name}
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-400"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 inset-x-0 p-3">
                  <p className="font-bold text-white text-sm">{cat.name}</p>
                  <p className="text-white/70 text-xs">{count} منتج</p>
                </div>
              </Link>
            )
          })}
        </div>
      </section>

      {/* Product catalog */}
      <section id="catalog" className="max-w-6xl mx-auto px-4 pb-12">
        <div className="flex items-end justify-between mb-6">
          <div>
            <h2 className="section-heading text-2xl">جميع المنتجات</h2>
            <span className="section-heading-accent" />
          </div>
          <span className="text-sm text-[#6b6b6b] mb-0.5">{otherProducts.length} منتج</span>
        </div>

        {otherProducts.length === 0 ? (
          <div className="text-center py-16 text-[#6b6b6b]">
            <p className="text-lg font-medium">لا توجد منتجات متاحة حالياً</p>
            <p className="text-sm mt-1">تفقد قريباً لمشاهدة المنتجات الجديدة</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {otherProducts.map((product) => {
              const cat = categories.find((c) => c.id === product.category_id)
              return (
                <ProductCard
                  key={product.id}
                  product={product}
                  category={cat}
                  onOrder={setOrderProduct}
                />
              )
            })}
          </div>
        )}
      </section>

      <WhatsAppOrderModal product={orderProduct} onClose={() => setOrderProduct(null)} />
    </div>
  )
}
